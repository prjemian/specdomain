.. $Id: howto.rst 1020 2012-07-15 22:29:27Z jemian $

==============================================================
How to use Sphinx to Document SPEC Macro Source Code Files
==============================================================

.. toctree::
   :maxdepth: 2

   howto-install
   howto-configure
   howto-build
   howto-markup
