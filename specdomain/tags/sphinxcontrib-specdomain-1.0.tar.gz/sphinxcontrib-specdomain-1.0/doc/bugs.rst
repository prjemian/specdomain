.. $Id: bugs.rst 1028 2012-07-16 06:06:58Z jemian $

.. _bugs:

===========
Known bugs
===========

* Duplicate ID warnings, for now, ignore them, the warning will be resolved in a future revision
* roles should link to directives, see *example.mac* to illustrate the problem
* fix the signature recognition for roles
* fix the signature handling for roles and directives
* the out-of-source example PNG shows a Python project, should be a SPEC project