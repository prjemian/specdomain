.. sphinxcontrib-specdomain-acceptancetest documentation master file, created by
   sphinx-quickstart on Tue Jun 12 12:22:03 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to sphinxcontrib-specdomain-acceptancetest's documentation!
===================================================================

Contents:

.. toctree::
   :maxdepth: 3

   test_doc

Example Python Source code documentation
=============================================

.. toctree::
   :maxdepth: 2

   python-example-source

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

.. * :ref:`modindex`

*documentation built*: 
|today|
