.. $Id: test-battery.mac.rst 994 2012-07-06 19:15:32Z jemian $

.. autospecmacro:: ../macros/test-battery.mac
