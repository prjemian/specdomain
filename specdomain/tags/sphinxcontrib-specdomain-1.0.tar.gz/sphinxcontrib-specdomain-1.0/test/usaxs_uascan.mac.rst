.. $Id: usaxs_uascan.mac.rst 994 2012-07-06 19:15:32Z jemian $

.. autospecmacro:: ../macros/usaxs_uascan.mac
