.. $Id: shutter.mac.rst 994 2012-07-06 19:15:32Z jemian $

.. caution:: This file is as-received.  
	No attempt to prepare it for ReST comments has been made.

.. autospecmacro:: ../macros/shutter.mac
