.. example documentation master file, created by
   sphinx-quickstart on Sun Jul 15 17:54:46 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to example's documentation!
===================================

.. autospecmacro:: hkl_ioc.mac

Contents:

.. toctree::
   :maxdepth: 2



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

