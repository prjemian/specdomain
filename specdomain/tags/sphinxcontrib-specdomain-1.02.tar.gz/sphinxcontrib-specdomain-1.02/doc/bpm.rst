.. $Id: bpm.rst 1107 2012-09-09 17:52:55Z jemian $

====================================================================
Example with more extensive reST markup
====================================================================

This example demonstrates how a file more extensive reST markup will be documented.::

	.. autospecmacro:: bpm.mac

.. autospecmacro:: bpm.mac
