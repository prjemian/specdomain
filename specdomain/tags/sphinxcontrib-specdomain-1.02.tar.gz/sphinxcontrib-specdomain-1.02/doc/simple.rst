.. $Id: simple.rst 1107 2012-09-09 17:52:55Z jemian $

====================================================================
Simple Example to Document a SPEC Macro File
====================================================================

This example demonstrates how a file with simple reST markup will be documented.::

	.. autospecmacro:: simple.mac

.. autospecmacro:: simple.mac
