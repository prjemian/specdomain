.. $Id: bugs.rst 1107 2012-09-09 17:52:55Z jemian $

.. _bugs:

===========
Known bugs
===========

* Duplicate ID warnings, for now, ignore them, the warning will be resolved in a future revision
* roles should link to directives, see *example.mac* to illustrate the problem
* fix the signature recognition for roles
* fix the signature handling for roles and directives
* the out-of-source example PNG shows a Python project, should be a SPEC project