.. $Id: changes.rst 1107 2012-09-09 17:52:55Z jemian $

#########
Changelog
#########

.. include:: ../CHANGES
