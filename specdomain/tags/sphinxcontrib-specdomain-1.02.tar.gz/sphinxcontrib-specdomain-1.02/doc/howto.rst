.. $Id: howto.rst 1107 2012-09-09 17:52:55Z jemian $

==============================================================
How to use Sphinx to Document SPEC Macro Source Code Files
==============================================================

.. toctree::
   :maxdepth: 2

   howto-install
   howto-configure
   howto-build
   howto-markup
