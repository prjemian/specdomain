.. $Id: other.rst 1107 2012-09-09 17:52:55Z jemian $

Other matters
==================

.. toctree::
   :maxdepth: 2

   downloads
   objectives
   todo
   bugs
   changes
   license
   authors

Cross-reference:

* :ref:`genindex`
* :ref:`search`
