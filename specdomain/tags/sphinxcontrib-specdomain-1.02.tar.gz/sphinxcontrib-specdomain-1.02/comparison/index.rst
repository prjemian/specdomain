.. sphinxcontrib-specdomain documentation master file, created by
   sphinx-quickstart on Tue Jun 12 12:23:26 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

============================================================
Comparison of SPEC Macro Source Code Documented with Sphinx
============================================================

This is an example of documenting SPEC macro source code with Sphinx.

.. seealso:: http://www.aps.anl.gov/Sectors/33_34/controls/spec/robodoc/auto_mac.html

.. autospecdir:: ./

.. toctree::
   :maxdepth: 2

   auto

Cross-reference:

* :ref:`genindex`
* :ref:`search`
