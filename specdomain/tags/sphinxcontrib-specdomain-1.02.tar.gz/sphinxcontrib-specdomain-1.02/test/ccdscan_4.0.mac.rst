.. $Id: ccdscan_4.0.mac.rst 1107 2012-09-09 17:52:55Z jemian $

.. autospecmacro:: ../macros/ccdscan_4.0.mac
