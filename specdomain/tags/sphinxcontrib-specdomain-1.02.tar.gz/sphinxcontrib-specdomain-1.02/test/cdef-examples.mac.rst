.. $Id: cdef-examples.mac.rst 1107 2012-09-09 17:52:55Z jemian $

.. autospecmacro:: ../macros/cdef-examples.mac
