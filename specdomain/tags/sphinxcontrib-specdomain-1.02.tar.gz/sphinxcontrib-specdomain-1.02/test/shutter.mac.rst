.. $Id: shutter.mac.rst 1107 2012-09-09 17:52:55Z jemian $

.. caution:: This file is as-received.  
	No attempt to prepare it for ReST comments has been made.

.. autospecmacro:: ../macros/shutter.mac
