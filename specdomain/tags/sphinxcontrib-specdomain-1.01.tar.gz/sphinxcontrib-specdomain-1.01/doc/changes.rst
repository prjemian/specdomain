.. $Id: changes.rst 919 2012-06-12 22:10:09Z jemian $

#########
Changelog
#########

.. include:: ../CHANGES
