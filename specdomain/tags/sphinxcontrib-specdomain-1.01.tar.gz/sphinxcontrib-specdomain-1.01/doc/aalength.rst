.. $Id: aalength.rst 1007 2012-07-12 22:56:32Z jemian $

====================================================================
Example with no reST markup
====================================================================

This example demonstrates how a file with no particular markup will be documented.::

	.. autospecmacro:: aalength.mac

.. autospecmacro:: aalength.mac
