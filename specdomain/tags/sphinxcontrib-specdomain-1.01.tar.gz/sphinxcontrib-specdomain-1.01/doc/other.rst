.. $Id: other.rst 1041 2012-07-16 18:46:41Z jemian $

Other matters
==================

.. toctree::
   :maxdepth: 2

   downloads
   objectives
   todo
   bugs
   changes
   license
   authors

Cross-reference:

* :ref:`genindex`
* :ref:`search`
