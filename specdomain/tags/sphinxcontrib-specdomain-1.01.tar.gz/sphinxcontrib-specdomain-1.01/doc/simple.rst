.. $Id: simple.rst 1028 2012-07-16 06:06:58Z jemian $

====================================================================
Simple Example to Document a SPEC Macro File
====================================================================

This example demonstrates how a file with simple reST markup will be documented.::

	.. autospecmacro:: simple.mac

.. autospecmacro:: simple.mac
