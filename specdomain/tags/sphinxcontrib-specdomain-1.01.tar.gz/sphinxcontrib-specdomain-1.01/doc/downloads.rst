.. $Id: downloads.rst 1036 2012-07-16 18:04:01Z jemian $

.. _downloads:

===========
Downloads
===========

home: 
	http://subversion.xray.aps.anl.gov/admin_bcdaext/specdomain

svn trunk:
	https://subversion.xray.aps.anl.gov/bcdaext/specdomain/trunk/src/specdomain/

svn releases:
	https://subversion.xray.aps.anl.gov/bcdaext/specdomain/tags/src/v1.0/

version 1.0 (2012-07-16)
	https://subversion.xray.aps.anl.gov/bcdaext/specdomain/tags/sphinxcontrib-specdomain-1.0.tar.gz (486 kB)
