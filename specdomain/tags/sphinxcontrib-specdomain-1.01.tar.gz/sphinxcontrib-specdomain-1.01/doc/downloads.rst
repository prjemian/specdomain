.. $Id: downloads.rst 1076 2012-08-15 16:40:40Z jemian $

.. _downloads:

===========
Downloads
===========

home: 
	http://subversion.xray.aps.anl.gov/admin_bcdaext/specdomain

svn trunk:
	https://subversion.xray.aps.anl.gov/bcdaext/specdomain/trunk/src/specdomain/

svn releases:
	
	- https://subversion.xray.aps.anl.gov/bcdaext/specdomain/tags/src/v1.01/
	- https://subversion.xray.aps.anl.gov/bcdaext/specdomain/tags/src/v1.0/

Source Distributions
---------------------------

version 1.01 (2012-08-15)
	https://subversion.xray.aps.anl.gov/bcdaext/specdomain/tags/sphinxcontrib-specdomain-1.01.tar.gz (495 kB)

version 1.0 (2012-07-16)
	https://subversion.xray.aps.anl.gov/bcdaext/specdomain/tags/sphinxcontrib-specdomain-1.0.tar.gz (486 kB)
