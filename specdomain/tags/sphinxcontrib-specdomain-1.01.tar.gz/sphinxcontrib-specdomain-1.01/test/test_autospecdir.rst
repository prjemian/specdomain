.. $Id: test_autospecdir.rst 1007 2012-07-12 22:56:32Z jemian $

.. autospecdir:: ../macros/

.. end
