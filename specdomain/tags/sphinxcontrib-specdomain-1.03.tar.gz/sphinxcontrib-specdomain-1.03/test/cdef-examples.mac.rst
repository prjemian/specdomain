.. $Id: cdef-examples.mac.rst 994 2012-07-06 19:15:32Z jemian $

.. autospecmacro:: ../macros/cdef-examples.mac
