.. $Id: references.rst 1105 2012-09-09 17:46:19Z jemian $

#######################
References
#######################


Sphinx documentation
====================

The Sphinx website:
    * The Sphinx home page
        http://sphinx.pocoo.org/index.html
    * The Sphinx documentation page
        http://sphinx.pocoo.org/contents.html
    * Sphinx markup constructs
        http://sphinx.pocoo.org/markup/index.html
      
Other helpful links:
    * Sphinx example and quickstart of pypi:
        http://packages.python.org/an_example_pypi_project/sphinx.html
    * Another overview of Sphinx commands:
        http://docs.geoserver.org/trunk/en/docguide/sphinx.html
      


reStructuredText documentation
==============================

    * reStructuredText home page
        http://docutils.sourceforge.net/rst.html
    * reStructuredText quick reference
        http://docutils.sourceforge.net/docs/user/rst/quickref.html
    * reStructuredText cheat sheet     
        http://docutils.sourceforge.net/docs/user/rst/cheatsheet.txt
    * reStructuredText directives
        http://docutils.sourceforge.net/docs/ref/rst/directives.html
      