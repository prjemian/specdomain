.. $Id: authors.rst 1041 2012-07-16 18:46:41Z jemian $

#########
Authors
#########

.. include:: ../AUTHORS
