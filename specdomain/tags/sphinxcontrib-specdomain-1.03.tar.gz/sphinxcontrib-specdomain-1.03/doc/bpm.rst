.. $Id: bpm.rst 1007 2012-07-12 22:56:32Z jemian $

====================================================================
Example with more extensive reST markup
====================================================================

This example demonstrates how a file more extensive reST markup will be documented.::

	.. autospecmacro:: bpm.mac

.. autospecmacro:: bpm.mac
